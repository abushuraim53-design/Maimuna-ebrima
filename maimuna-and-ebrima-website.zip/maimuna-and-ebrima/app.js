const $ = (id) => document.getElementById(id);

const photoInput = $("photoInput");
photoInput.addEventListener("change", () => {
  const file = photoInput.files && photoInput.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    $("mainPhoto").src = reader.result;
    try { localStorage.setItem("me-main-photo", reader.result); } catch(e) {}
  };
  reader.readAsDataURL(file);
});
const savedPhoto = localStorage.getItem("me-main-photo");
if (savedPhoto) $("mainPhoto").src = savedPhoto;

const memoryInput = $("memoryInput");
const gallery = $("gallery");
let memories = [];
try { memories = JSON.parse(localStorage.getItem("me-memories") || "[]"); } catch(e) {}
function renderMemories(){
  gallery.innerHTML = "";
  if (!memories.length) {
    gallery.innerHTML = '<div class="empty-memory">Your memories will appear here when you add photos.</div>';
    return;
  }
  memories.forEach(src => {
    const img = document.createElement("img");
    img.src = src; img.alt = "A saved memory";
    gallery.appendChild(img);
  });
}
renderMemories();
memoryInput.addEventListener("change", async () => {
  const files = Array.from(memoryInput.files || []).slice(0, 8);
  for (const file of files) {
    const data = await new Promise(resolve => {
      const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.readAsDataURL(file);
    });
    memories.push(data);
  }
  memories = memories.slice(-12);
  try { localStorage.setItem("me-memories", JSON.stringify(memories)); } catch(e) {
    alert("Your browser storage is full. Try adding fewer or smaller photos.");
  }
  renderMemories(); memoryInput.value = "";
});

const questions = [
  "What is one thing that helps you feel genuinely heard?",
  "What is a small act of kindness you remember?",
  "What does a healthy relationship mean to you?",
  "What is something you would like someone to understand about you?",
  "How can two people disagree while still respecting each other?"
];
let qIndex = Math.floor(Math.random() * questions.length);
$("dailyQuestion").textContent = questions[qIndex];
$("nextQuestion").addEventListener("click", () => {
  qIndex = (qIndex + 1) % questions.length;
  $("dailyQuestion").textContent = questions[qIndex];
});

$("journal").value = localStorage.getItem("me-journal") || "";
$("saveJournal").addEventListener("click", () => {
  localStorage.setItem("me-journal", $("journal").value);
  $("saveStatus").textContent = "Saved on this device.";
});

const dateInput = $("specialDate");
dateInput.value = localStorage.getItem("me-date") || "";
function updateCountdown(){
  if (!dateInput.value) { $("countdown").textContent = "Choose a date to see the countdown."; return; }
  const target = new Date(dateInput.value + "T00:00:00");
  const today = new Date(); today.setHours(0,0,0,0);
  const days = Math.round((target - today) / 86400000);
  $("countdown").textContent = days > 0 ? `${days} days to go` : days === 0 ? "That date is today" : `${Math.abs(days)} days since that date`;
}
dateInput.addEventListener("change", () => { localStorage.setItem("me-date", dateInput.value); updateCountdown(); });
updateCountdown();

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}